# mypackage
This library was created as an example of how to create and publish a Python Package.

# Building Package Locally
'python setup.py sdist'

# Installing package on Github
' pip install git+https://github.com/huzaius/example-python-package.git '

#Updating Package from Github
' pip install --upgrade git+https://github.com/huzaius/example-python-package.git '
